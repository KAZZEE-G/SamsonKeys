'use client'
import { useState } from 'react'
import Nav from '@/components/public/Nav'
import Footer from '@/components/public/Footer'

const S = {
  label: { fontSize: '9px', fontWeight: 300, letterSpacing: '0.38em', textTransform: 'uppercase' as const, color: 'rgba(255,255,255,0.35)', display: 'block', marginBottom: '7px' },
  input: { background: 'transparent', border: 'none', borderBottom: '1px solid rgba(255,255,255,0.12)', color: '#fff', fontSize: '14px', fontWeight: 300, fontFamily: 'DM Sans, sans-serif', padding: '10px 0', outline: 'none', width: '100%', transition: 'border-color 0.2s' },
}

const SUBJECTS = ['General', 'Listing enquiry', 'Private buyer', 'Press', 'Other']

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', subject: 'General', message: '' })
  const [status, setStatus] = useState<'idle' | 'sending' | 'done' | 'error'>('idle')

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setStatus('sending')
    const res = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
    setStatus(res.ok ? 'done' : 'error')
  }

  return (
    <>
      <Nav />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', minHeight: 'calc(100vh - 62px)' }}>
        {/* Left */}
        <div style={{ padding: '5rem 3.5rem', borderRight: '1px solid var(--border)' }}>
          <span style={{ ...S.label, marginBottom: '2.5rem', display: 'block' }}>Get in touch</span>
          <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(36px,4vw,58px)', fontWeight: 300, color: '#fff', lineHeight: 1.0, marginBottom: '2rem', letterSpacing: '-0.01em' }}>
            We read<br />everything<br />we receive.
          </h2>
          <p style={{ fontSize: '13px', fontWeight: 300, color: 'rgba(255,255,255,0.4)', lineHeight: 1.9, marginBottom: '3rem' }}>
            No bots. No ticket queues. If you have a question about a listing, a submission, or anything else, someone on our team will read it and reply.
          </p>
          <div>
            {[
              { icon: 'Email',   title: 'hello@samsonkeys.com',       sub: 'For general enquiries. We reply within 2 business days.' },
              { icon: 'Sales',   title: 'Private buyer enquiries',      sub: 'For off-market or high-value piece discussions, use the form and mark it Private.' },
              { icon: 'Press',   title: 'press@samsonkeys.com',        sub: 'For media, editorial, and partnership enquiries.' },
              { icon: 'Sellers', title: 'Questions about applying',     sub: 'Head to the Submit Work page to start an application.' },
            ].map(({ icon, title, sub }) => (
              <div key={icon} style={{ display: 'flex', gap: '1.5rem', padding: '1.5rem 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ fontSize: '9px', fontWeight: 300, letterSpacing: '0.3em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.3)', minWidth: '80px', marginTop: '3px' }}>{icon}</span>
                <div>
                  <p style={{ fontSize: '13px', fontWeight: 300, color: '#fff', marginBottom: '5px' }}>{title}</p>
                  <p style={{ fontSize: '11px', fontWeight: 300, color: 'rgba(255,255,255,0.35)', lineHeight: 1.7 }}>{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right */}
        <div style={{ padding: '5rem 3.5rem', background: 'var(--surface)' }}>
          <p style={{ ...S.label, marginBottom: '2.5rem' }}>Send a message</p>
          {status === 'done' ? (
            <div style={{ padding: '3rem 0' }}>
              <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '30px', fontWeight: 300, color: '#fff', marginBottom: '1rem' }}>Message sent.</p>
              <p style={{ fontSize: '13px', fontWeight: 300, color: 'rgba(255,255,255,0.4)', lineHeight: 1.8 }}>We will reply within 2 business days.</p>
            </div>
          ) : (
            <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: '1.8rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  <label style={S.label}>Name</label>
                  <input required style={S.input} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Your name" />
                </div>
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  <label style={S.label}>Email</label>
                  <input required type="email" style={S.input} value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="you@email.com" />
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <label style={S.label}>Subject</label>
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  {SUBJECTS.map(s => (
                    <button key={s} type="button" onClick={() => setForm(f => ({ ...f, subject: s }))} style={{
                      fontSize: '9px', fontWeight: 300, letterSpacing: '0.2em', textTransform: 'uppercase',
                      padding: '5px 12px', cursor: 'pointer', transition: 'all 0.2s', background: form.subject === s ? '#fff' : 'none',
                      color: form.subject === s ? '#000' : 'rgba(255,255,255,0.35)',
                      border: form.subject === s ? '1px solid #fff' : '1px solid rgba(255,255,255,0.1)',
                    }}>{s}</button>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <label style={S.label}>Message</label>
                <textarea required style={{ ...S.input, resize: 'vertical', minHeight: '130px' }} value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))} placeholder="What would you like to know?" />
              </div>
              <button type="submit" disabled={status === 'sending'} style={{ display: 'inline-flex', alignItems: 'center', gap: '10px', fontSize: '10px', fontWeight: 300, letterSpacing: '0.3em', textTransform: 'uppercase', color: '#000', background: '#fff', padding: '14px 28px', border: 'none', cursor: 'pointer', alignSelf: 'flex-start' }}>
                {status === 'sending' ? 'Sending...' : 'Send Message →'}
              </button>
              {status === 'error' && <p style={{ fontSize: '12px', color: '#c85050' }}>Something went wrong. Please try again.</p>}
              <p style={{ fontSize: '10px', fontWeight: 300, color: 'rgba(255,255,255,0.3)', lineHeight: 1.7 }}>We respond to every message within 2 business days.</p>
            </form>
          )}
        </div>
      </div>
      <Footer />
    </>
  )
}
