import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { name, email, subject, message } = body
  if (!name || !email || !message) return NextResponse.json({ error: 'Missing fields' }, { status: 400 })
  const { error } = await supabaseAdmin.from('contact_messages').insert({ name, email, subject, message })
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ ok: true })
}

export async function GET() {
  const { data, error } = await supabaseAdmin.from('contact_messages').select('*').order('created_at', { ascending: false })
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}
