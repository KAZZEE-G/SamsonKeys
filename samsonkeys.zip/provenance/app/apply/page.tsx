'use client'
import { useState } from 'react'
import Nav from '@/components/public/Nav'
import Footer from '@/components/public/Footer'

const S = {
  label: { fontSize: '9px', fontWeight: 300, letterSpacing: '0.38em', textTransform: 'uppercase' as const, color: 'rgba(255,255,255,0.35)', display: 'block', marginBottom: '7px' },
  input: { background: 'transparent', border: 'none', borderBottom: '1px solid rgba(255,255,255,0.12)', color: '#fff', fontSize: '14px', fontWeight: 300, fontFamily: 'DM Sans, sans-serif', padding: '10px 0', outline: 'none', width: '100%', transition: 'border-color 0.2s' },
}

export default function ApplyPage() {
  const [form, setForm] = useState({ first_name: '', last_name: '', email: '', website: '', category: '', pieces_per_year: '', pitch: '' })
  const [status, setStatus] = useState<'idle' | 'sending' | 'done' | 'error'>('idle')

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setStatus('sending')
    const res = await fetch('/api/applications', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
    setStatus(res.ok ? 'done' : 'error')
  }

  return (
    <>
      <Nav />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', minHeight: 'calc(100vh - 62px)' }}>
        {/* Left */}
        <div style={{ padding: '5rem 3.5rem', borderRight: '1px solid var(--border)', background: 'var(--surface)' }}>
          <span style={{ ...S.label, marginBottom: '2.5rem', display: 'block' }}>Submit your work</span>
          <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 'clamp(36px,4vw,58px)', fontWeight: 300, color: '#fff', lineHeight: 1.0, marginBottom: '2rem', letterSpacing: '-0.01em' }}>
            You pitch.<br />We decide.<br />You keep 85%.
          </h2>
          <p style={{ fontSize: '13px', fontWeight: 300, color: 'rgba(255,255,255,0.4)', lineHeight: 1.9, marginBottom: '3rem' }}>
            We sell art, motor, property, jewellery, watches, collectibles, memorabilia, and anything else that is genuinely rare. If you have fewer than 8 pieces to offer this year, we want to hear from you.
          </p>
          <ul style={{ listStyle: 'none', marginBottom: '3rem' }}>
            {[
              'Fewer than 8 pieces available this calendar year. Non-negotiable.',
              'Physical or authenticated digital items. Provenance documentation required.',
              'Pricing must reflect genuine value. We push back on underpricing.',
              'Seller can fulfil verified shipping or handover for physical items.',
              'We respond to every application within 14 days. Yes or no, you will know.',
            ].map((item, i) => (
              <li key={i} style={{ display: 'flex', gap: '14px', padding: '14px 0', borderBottom: '1px solid var(--border)', fontSize: '12px', fontWeight: 300, color: 'rgba(255,255,255,0.4)', lineHeight: 1.7 }}>
                <span style={{ color: 'rgba(255,255,255,0.25)', fontSize: '10px', marginTop: '4px', flexShrink: 0 }}>—</span>
                {item}
              </li>
            ))}
          </ul>

          {/* Commission split */}
          <div style={{ padding: '2rem', border: '1px solid rgba(255,255,255,0.12)' }}>
            <p style={{ ...S.label, marginBottom: '1.5rem' }}>Commission split</p>
            {[
              { label: 'You', pct: '85%', width: '85%', color: '#fff' },
              { label: 'Samson Keys', pct: '15%', width: '15%', color: 'rgba(255,255,255,0.25)' },
            ].map(r => (
              <div key={r.label} style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                <span style={{ fontSize: '9px', fontWeight: 300, letterSpacing: '0.2em', color: 'rgba(255,255,255,0.35)', minWidth: '90px', textTransform: 'uppercase' }}>{r.label}</span>
                <div style={{ flex: 1, height: '1px', background: 'rgba(255,255,255,0.08)' }}>
                  <div style={{ height: '100%', background: r.color, width: r.width }} />
                </div>
                <span style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '22px', fontWeight: 300, color: r.color, minWidth: '50px', textAlign: 'right' }}>{r.pct}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right — form */}
        <div style={{ padding: '5rem 3.5rem' }}>
          <p style={{ ...S.label, marginBottom: '2.5rem' }}>Application form</p>
          {status === 'done' ? (
            <div style={{ padding: '3rem 0' }}>
              <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: '30px', fontWeight: 300, color: '#fff', marginBottom: '1rem' }}>Application received.</p>
              <p style={{ fontSize: '13px', fontWeight: 300, color: 'rgba(255,255,255,0.4)', lineHeight: 1.8 }}>We will review it personally and reply within 14 days.</p>
            </div>
          ) : (
            <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: '1.8rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                {[['first_name', 'First name', 'Your name'], ['last_name', 'Last name', 'Your surname']].map(([k, l, p]) => (
                  <div key={k} style={{ display: 'flex', flexDirection: 'column' }}>
                    <label style={S.label}>{l}</label>
                    <input required style={S.input} value={(form as Record<string, string>)[k]} onChange={e => setForm(f => ({ ...f, [k]: e.target.value }))} placeholder={p} />
                  </div>
                ))}
              </div>
              {[['email', 'Email', 'you@email.com', 'email'], ['website', 'Website or portfolio', 'https://', 'url']].map(([k, l, p, t]) => (
                <div key={k} style={{ display: 'flex', flexDirection: 'column' }}>
                  <label style={S.label}>{l}</label>
                  <input type={t} style={S.input} value={(form as Record<string, string>)[k]} onChange={e => setForm(f => ({ ...f, [k]: e.target.value }))} placeholder={p} required={k === 'email'} />
                </div>
              ))}
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <label style={S.label}>Category</label>
                <select required style={{ ...S.input, appearance: 'none', cursor: 'pointer' }} value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
                  <option value="" disabled>What are you selling?</option>
                  {['Art','Motor','Property','Jewellery','Watch','Collectible','Memorabilia','Other'].map(c => <option key={c} value={c.toLowerCase()}>{c}</option>)}
                </select>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <label style={S.label}>Pieces available this year</label>
                <select required style={{ ...S.input, appearance: 'none', cursor: 'pointer' }} value={form.pieces_per_year} onChange={e => setForm(f => ({ ...f, pieces_per_year: e.target.value }))}>
                  <option value="" disabled>How many?</option>
                  {['1','2 to 4','5 to 7','8 (maximum)'].map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <label style={S.label}>Your pitch</label>
                <textarea required style={{ ...S.input, resize: 'vertical', minHeight: '110px' }} value={form.pitch} onChange={e => setForm(f => ({ ...f, pitch: e.target.value }))} placeholder="Tell us what you are selling, why it is rare, and what makes it worth owning. Be direct." />
              </div>
              <button type="submit" disabled={status === 'sending'} style={{ display: 'inline-flex', alignItems: 'center', gap: '10px', fontSize: '10px', fontWeight: 300, letterSpacing: '0.3em', textTransform: 'uppercase', color: '#000', background: '#fff', padding: '14px 28px', border: 'none', cursor: 'pointer', alignSelf: 'flex-start', transition: 'opacity 0.2s' }}>
                {status === 'sending' ? 'Submitting...' : 'Submit Application →'}
              </button>
              {status === 'error' && <p style={{ fontSize: '12px', color: '#c85050' }}>Something went wrong. Please try again.</p>}
              <p style={{ fontSize: '10px', fontWeight: 300, color: 'rgba(255,255,255,0.3)', lineHeight: 1.7 }}>No listing fee. No exclusivity clause. We review everything personally and respond within 14 days.</p>
            </form>
          )}
        </div>
      </div>
      <Footer />
    </>
  )
}
